var database = require('mysql');
var fs = require('fs');
var url = require('url');
var express = require('express');
const bodyParser = require('body-parser');

const port = 1254;
const host = '192.168.0.105'


const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.listen(port,host, () => {
    console.log('Our express server is up on port ' + port + ":"+ host);
});

app.post("/saveStudent",(req,res) => {
    var firstName = req.body.firstName;
    var lastName = req.body.lastName;
    var email = req.body.email;

    var sql = "insert into student values("+ "'" + firstName+ "'" +","+ "'" +lastName + "'" +","+ "'" + email + "'"+ ")";
    con.query(sql, function(err, result){
        if(err != null){
            console.log(err);
        }
        console.log(res);
        res.json(true);
    })
});

app.get("/getStudents",async (req,res) => {
    var sql = "select * from student";
    let student = Array();
    con.query(sql, function (err, result) {
        result.forEach(element => {
            student.push({
                firstName: element.firstName,
                lastName: element.lasttName,
                email: element.email
            });
        });
        console.log(student);
        res.jsonp(student);
    });
});




function dbConfig() {
    return {
        host: "localhost",
        user: "student",
        password: "student",
        database:'student'
    };
}

var con = database.createConnection(dbConfig());

con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
});
