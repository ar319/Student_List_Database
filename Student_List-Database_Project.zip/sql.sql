create database student;
create user 'student'@'localhost' identified by 'student';
GRANT ALL on student.* to 'student'@'localhost' with GRANT OPTION;
